// Do not modify this file by hand!
// Re-generate this file by running lit-localize

/* eslint-disable no-irregular-whitespace */

export const templates = {
  s229fb4df9ecf3ed1: `ログイン`,
  s45dab30b4d2d3c14: `ログイン`,
  s749c72374d54863f: `閉まっている`,
  s772ce5f935d58e37: `説明`,
  s8d9d6501de2bbd98: `データを追加`,
  sc72cca9281ef6073: `日にち`,
  se296c068d76c3b02: `❤で作られました Mochammad Ravly`,
  sef49b2c68fd1e332: `名前`,
  sf9a862bfd829397e: `ダッシュボード`,
};
