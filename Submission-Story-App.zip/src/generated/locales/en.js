// Do not modify this file by hand!
// Re-generate this file by running lit-localize

/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */

export const templates = {
  s229fb4df9ecf3ed1: `Logout`,
  s45dab30b4d2d3c14: `Login`,
  s749c72374d54863f: `Close`,
  s772ce5f935d58e37: `Description`,
  s8d9d6501de2bbd98: `Add Data`,
  sc72cca9281ef6073: `Date`,
  se296c068d76c3b02: `Built with ❤ by Mochammad Ravly`,
  sef49b2c68fd1e332: `Name`,
  sf9a862bfd829397e: `Dashboard`,
};
